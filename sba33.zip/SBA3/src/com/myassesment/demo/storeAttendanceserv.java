package com.myass.demo;

import java.io.IOException;


import java.io.PrintWriter;
import java.util.Date;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.myassesment.dao.StudentDao;
import com.myassesment.model.Attendance;
import com.myassesment.model.Students;

@WebServlet("/storeAttendanceserv")
public class storeAttendanceserv extends HttpServlet {
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String[] attendancestatus=request.getParameterValues("status");
		HttpSession session=request.getSession();
		
		ArrayList<Students> studentsem=(ArrayList<Students>)session.getAttribute("studs");
		
		for(Students student:studentsem) 
		{
		Attendance attendance=new Attendance(student.getStudId(),student.getStudName(),student.getSem(), new Date(),"");
		StudentDao dao=new StudentDao();
		dao.attendanceInsert(attendance);
		
		}
		
		
		for(String attend:attendancestatus)
		{
			StudentDao dao=new StudentDao();
			dao.updateAttendance(attend);
		}
		
		out.print("<body bgcolor=\"black\" align=\"center\" style=\"color: green\">");
		out.print("Attendance Marked");
		out.print("<br><br><br>");
		out.print("<form action='mainForm.jsp'>");
		out.print("<input type='submit' value='MainMenu' name='return'>");
		out.print("</form>");
		
		
		out.print("</body>");

	
	}

}
